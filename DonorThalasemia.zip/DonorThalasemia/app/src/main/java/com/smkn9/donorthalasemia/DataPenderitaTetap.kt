package com.smkn9.donorthalasemia

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DataPenderitaTetap(private val dataList: List<DataPenderita>,
                         private val googleFormLink: String) :
    RecyclerView.Adapter<DataPenderitaTetap.DataPenderitaViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataPenderitaViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_pendonor_tetap, parent, false)
        return DataPenderitaViewHolder(view)
    }

    override fun onBindViewHolder(holder: DataPenderitaViewHolder, position: Int) {
        val data = dataList[position]
        holder.idPenderita.text = data.id_penderita
        holder.namaPasien.text = data.nama_pasien
        holder.kebutuhanDonor.text = data.kebutuhan_donor
        holder.kuotaPenderita.text = data.kuota

        holder.buttonDaftar.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(googleFormLink))
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount() = dataList.size

    class DataPenderitaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val idPenderita: TextView = itemView.findViewById(R.id.idPenderita)
        val namaPasien: TextView = itemView.findViewById(R.id.namaPasien)
        val kebutuhanDonor: TextView = itemView.findViewById(R.id.kebutuhanDonor)
        val kuotaPenderita: TextView = itemView.findViewById(R.id.kuotaPenderita)
        val buttonDaftar: Button = itemView.findViewById(R.id.buttonDaftar)
    }
}
