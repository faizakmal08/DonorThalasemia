package com.smkn9.donorthalasemia

import Student
import StudentAdapter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.gson.Gson
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException

class PeringkatActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private val client = OkHttpClient()
    private val handler = Handler(Looper.getMainLooper())
    private val refreshInterval: Long = 3000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_peringkat)
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        startAutoRefresh()
        fetchData()
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout)
        swipeRefreshLayout.setOnRefreshListener {
            fetchData()
        }
        startAutoRefresh()
    }
    private fun startAutoRefresh() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                fetchData()
                handler.postDelayed(this, refreshInterval)
            }
        }, refreshInterval)
    }

    private fun fetchData() {
        val url = "https://script.google.com/macros/s/AKfycby336pdGB5Prp0BKmG7nFy0MCsLadN3osOPS1jEBq3Nth8w1iuJHgPY8gSMz559w4fW/exec"
        val request = Request.Builder().url(url).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
                runOnUiThread{
                    swipeRefreshLayout.isRefreshing = false
                }
            }


            override fun onResponse(call: Call, response: Response) {
                response.body?.let {body ->
                    val gson = Gson()
                    val students = gson.fromJson(body.string(), Array<Student>::class.java).toList()
                    runOnUiThread{
                        recyclerView.adapter = StudentAdapter(students)
                        swipeRefreshLayout.isRefreshing = false
                    }
                }
            }
        })
    }
}