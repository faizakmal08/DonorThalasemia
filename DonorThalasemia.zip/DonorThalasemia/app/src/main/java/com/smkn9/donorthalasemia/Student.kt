data class Student (
    val namaSiswa : String,
    val namaPendonor : String,
    val poin : Int

)