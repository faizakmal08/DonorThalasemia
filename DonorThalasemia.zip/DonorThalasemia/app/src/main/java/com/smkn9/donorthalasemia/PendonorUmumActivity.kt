package com.smkn9.donorthalasemia

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class PendonorUmumActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pendonor_umum)

        val btnGolDarA = findViewById<Button>(R.id.btnGolDarA)
        val btnGolDarB = findViewById<Button>(R.id.btnGolDarB)
        val btnGolDarAB = findViewById<Button>(R.id.btnGolDarAB)
        val btnGolDarO = findViewById<Button>(R.id.btnGolDarO)

        btnGolDarA.setOnClickListener {
            startActivity(Intent(this, GoldarAActivity::class.java))
        }

        btnGolDarB.setOnClickListener {
            startActivity(Intent(this, GoldarBActivity::class.java))
        }

        btnGolDarAB.setOnClickListener {
            startActivity(Intent(this, GoldarABActivity::class.java))
        }

        btnGolDarO.setOnClickListener {
            startActivity(Intent(this, GoldarOActivity::class.java))
        }
    }
}