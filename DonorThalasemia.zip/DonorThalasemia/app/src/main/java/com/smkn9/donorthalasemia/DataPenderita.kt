package com.smkn9.donorthalasemia

data class DataPenderita(
    val id_penderita: String,
    val nama_pasien: String,
    val kebutuhan_donor: String,
    val kuota: String
)