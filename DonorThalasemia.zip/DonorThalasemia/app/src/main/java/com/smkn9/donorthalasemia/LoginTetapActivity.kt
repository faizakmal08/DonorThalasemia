package com.smkn9.donorthalasemia

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley

class LoginTetapActivity : AppCompatActivity() {

    private lateinit var inputNama: EditText
    private lateinit var inputNIS: EditText
    private lateinit var spinnerGolonganDarah: Spinner
    private lateinit var buttonLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_tetap)

        inputNama = findViewById(R.id.inputNama)
        inputNIS = findViewById(R.id.inputNIS)
        spinnerGolonganDarah = findViewById(R.id.spinnerGolonganDarah)
        buttonLogin = findViewById(R.id.buttonLogin)

        buttonLogin.setOnClickListener {
            val nama = inputNama.text.toString()
            val nis = inputNIS.text.toString()
            val golonganDarah = spinnerGolonganDarah.selectedItem.toString()

            if (nama.isNotEmpty() && nis.isNotEmpty()) {
                validateLogin(nama, nis, golonganDarah)
            } else {
                Toast.makeText(this, "Isi semua data terlebih dahulu", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun validateLogin(nama: String, nis: String, golonganDarah: String) {
        val url = "https://script.google.com/macros/s/AKfycbyChpIu4mPier2y7-vEHBEsFaxdBo1Rx4E2FBdE3wDiwz8LjmmC0ExBP9Z2fPkcGCh0YQ/exec?mode=getDonorData"

        val requestQueue = Volley.newRequestQueue(this)

        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET, url, null,
            { response ->
                try {
                    val status = response.getString("status")
                    if (status == "success") {
                        val dataArray = response.getJSONArray("data")
                        var isValidUser = false

                        for (i in 0 until dataArray.length()) {
                            val item = dataArray.getJSONObject(i)

                            val namaPendonor = item.getString("Nama Pendonor")
                            val nisPendonor = item.getString("NIS")
                            val goldarPendonor = item.getString("Gol Darah")

                            if (namaPendonor == nama && nisPendonor == nis && goldarPendonor == golonganDarah) {
                                isValidUser = true
                                navigateToActivity(golonganDarah)
                                break
                            }
                        }

                        if (!isValidUser) {
                            Toast.makeText(this, "Data tidak valid", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(this, "Gagal mendapatkan data dari server", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(this, "Error parsing data: ${e.message}", Toast.LENGTH_LONG).show()
                }
            },
            { error ->
                error.printStackTrace()
                Toast.makeText(this, "Error: ${error.message}", Toast.LENGTH_LONG).show()
            }
        )

        requestQueue.add(jsonObjectRequest)
    }

    private fun navigateToActivity(golonganDarah: String) {
        val intent = when (golonganDarah) {
            "A" -> Intent(this, GolonganA::class.java)
            "B" -> Intent(this, GolonganB::class.java)
            "AB" -> Intent(this, GolonganAB::class.java)
            "O" -> Intent(this, GolonganO::class.java)
            else -> null
        }

        intent?.let { startActivity(it) }
    }
}
