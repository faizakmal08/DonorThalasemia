package com.smkn9.donorthalasemia

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DataPenderitaAdapter(private val dataList: List<DataPenderita>) :
    RecyclerView.Adapter<DataPenderitaAdapter.DataPenderitaViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataPenderitaViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_data_penderita, parent, false)
        return DataPenderitaViewHolder(view)
    }

    override fun onBindViewHolder(holder: DataPenderitaViewHolder, position: Int) {
        val data = dataList[position]
        holder.idPenderita.text = data.id_penderita
        holder.namaPasien.text = data.nama_pasien
        holder.kebutuhanDonor.text = data.kebutuhan_donor
        holder.kuotaPenderita.text = data.kuota
    }

    override fun getItemCount() = dataList.size

    class DataPenderitaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val idPenderita: TextView = itemView.findViewById(R.id.idPenderita)
        val namaPasien: TextView = itemView.findViewById(R.id.namaPasien)
        val kebutuhanDonor: TextView = itemView.findViewById(R.id.kebutuhanDonor)
        val kuotaPenderita: TextView = itemView.findViewById(R.id.kuotaPenderita)
    }
}