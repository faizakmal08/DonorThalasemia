import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.smkn9.donorthalasemia.R


class StudentAdapter(private val students: List<Student>) :
    RecyclerView.Adapter<StudentAdapter.StudentViewHolder>() {

    init {
        students.sortedByDescending { it.poin }
    }

    class StudentViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvRank: TextView = view.findViewById(R.id.tvRank)
        val tvName: TextView = view.findViewById(R.id.tvName)
        val tvDonor: TextView = view.findViewById(R.id.tvDonor)
        val tvPoints: TextView = view.findViewById(R.id.tvPoints)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StudentViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_item_student, parent, false)
        return StudentViewHolder(view)
    }

    override fun onBindViewHolder(holder: StudentViewHolder, position: Int) {
        val student = students[position]

        holder.tvRank.text = (position + 1).toString()
        holder.tvDonor.text = student.namaPendonor
        holder.tvPoints.text = student.poin.toString()


        if (position == 0) {
            holder.itemView.setBackgroundColor(Color.parseColor("#FFD700"));
        } else if (position == 1) {
            holder.itemView.setBackgroundColor(Color.parseColor("#C0C0C0"));
        } else if (position == 2) {
            holder.itemView.setBackgroundColor(Color.parseColor("#CD7F32"));
        } else {
            holder.itemView.setBackgroundColor(Color.WHITE); // Putih
        }
    }

    override fun getItemCount() = students.size
}
