package com.smkn9.donorthalasemia

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.denzcoskun.imageslider.ImageSlider
import com.denzcoskun.imageslider.constants.ScaleTypes
import com.denzcoskun.imageslider.models.SlideModel
import com.ms.square.android.expandabletextview.ExpandableTextView
import android.widget.Toast
import android.util.Log
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.app.Dialog
import android.os.Message





class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val imageList = ArrayList<SlideModel>() // Membuat daftar gambar
        imageList.add(SlideModel("https://firebasestorage.googleapis.com/v0/b/ulasan-thalassemia.appspot.com/o/IMG_9829.JPG?alt=media&token=260f9ad1-dfee-4f4a-93b2-a4b04921d13b", ScaleTypes.CENTER_CROP))
        imageList.add(SlideModel("https://firebasestorage.googleapis.com/v0/b/musikpjbl.appspot.com/o/IMG_9784.JPG?alt=media&token=d97fcbfe-9902-4579-8bc5-dc3e53db82ab", ScaleTypes.CENTER_CROP))
        imageList.add(SlideModel("https://firebasestorage.googleapis.com/v0/b/musikpjbl.appspot.com/o/IMG_9786.JPG?alt=media&token=aa940b03-03dd-4d0c-8de1-6ffb5df415f7", ScaleTypes.CENTER_CROP))
        imageList.add(SlideModel("https://firebasestorage.googleapis.com/v0/b/musikpjbl.appspot.com/o/IMG_9831.JPG?alt=media&token=e66dc05b-32b1-432e-8d7c-2d17f178c828", ScaleTypes.CENTER_CROP))

        val imageSlider = findViewById<ImageSlider>(R.id.image_slider)
        imageSlider.setImageList(imageList)

        val marqueeText = findViewById<TextView>(R.id.marqueeText)
        marqueeText.isSelected = true

        val expTv1 = findViewById<ExpandableTextView>(R.id.sample1)
        expTv1.setText(getString(R.string.dummyText))

        // Temukan ImageButton dan tambahkan setOnClickListener
        val immgbtn1 = findViewById<ImageButton>(R.id.immgbtn1)
        immgbtn1.setOnClickListener {
            Toast.makeText(this, "Menuju Registrasi", Toast.LENGTH_SHORT).show()
            val url = "https://forms.gle/LpSXeKCuNAFSSYJw6"
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse(url)
            startActivity(intent)
        }
        val immgbtn2 = findViewById<ImageButton>(R.id.immgbtn2)
        immgbtn2.setOnClickListener {
            Toast.makeText(this, "Menuju Login Pendonor Tetap", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginTetapActivity::class.java)
            startActivity(intent)
        }
        val immgbtn3 = findViewById<ImageButton>(R.id.immgbtn3)
        immgbtn3.setOnClickListener {
            Toast.makeText(this, "Menuju Pendonor Umum", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, PendonorUmumActivity::class.java)
            startActivity(intent)
        }
        val immgbtn4 = findViewById<ImageButton>(R.id.immgbtn4)
        immgbtn4.setOnClickListener {
            Toast.makeText(this, "Menuju Peringkat", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, PeringkatActivity::class.java)
            startActivity(intent)
        }


        val webView: WebView = findViewById(R.id.webview_facebook_comments)
        val webSettings: WebSettings = webView.settings

        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptThirdPartyCookies(webView, true)
        cookieManager.setAcceptCookie(true)

        webSettings.javaScriptEnabled = true
        webSettings.javaScriptCanOpenWindowsAutomatically = true
        webSettings.setSupportMultipleWindows(true)
        webSettings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        webSettings.cacheMode = WebSettings.LOAD_NO_CACHE


        webView.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                val context = view?.context ?: return false
                val newWebView = WebView(context)
                val dialog = Dialog(view?.context ?: return false).apply {
                    setContentView(newWebView)
                    setOnDismissListener {
                        newWebView.destroy()
                    }
                }
                dialog.show()

                newWebView.webChromeClient = this
                resultMsg?.let {
                    (it.obj as WebView.WebViewTransport).webView = newWebView
                    it.sendToTarget()
                }
                return true
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)

                webView.evaluateJavascript(
                    "(function() { return document.body.scrollHeight; })();"
                ) { height ->
                    val contentHeight = height.toFloatOrNull() ?: return@evaluateJavascript
                    webView.layoutParams.height = contentHeight.toInt()
                    webView.requestLayout()
                }
            }
        }

        webView.loadUrl("http://ulasandonordarahthalasemia.wuaze.com/?i=1&t=" + System.currentTimeMillis())

    }

    fun postComment() {
        val webView: WebView = findViewById(R.id.webview_facebook_comments)

        // Kirim komentar dengan JavaScript di dalam halaman (jika ada fungsi JS)
        webView.evaluateJavascript("javascript:submitCommentForm()", null)

        // Jika tidak ada fungsi JS, muat ulang halaman
        webView.evaluateJavascript("javascript:location.reload()", null)
    }

}