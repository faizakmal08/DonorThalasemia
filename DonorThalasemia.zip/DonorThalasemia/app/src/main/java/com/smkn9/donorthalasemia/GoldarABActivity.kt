package com.smkn9.donorthalasemia

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request // Ini adalah impor yang benar
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley

class GoldarABActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goldar_ab)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        fetchData("AB")
    }

    private fun fetchData(golongan: String) {
        val url = "https://script.google.com/macros/s/AKfycbyChpIu4mPier2y7-vEHBEsFaxdBo1Rx4E2FBdE3wDiwz8LjmmC0ExBP9Z2fPkcGCh0YQ/exec?golongan=$golongan"

        val request = JsonArrayRequest(
            Request.Method.GET, url, null,
            { response ->
                val listData = mutableListOf<DataPenderita>()
                for (i in 0 until response.length()) {
                    val item = response.getJSONObject(i)

                    // Ambil data dasar
                    val idPenderita = item.getString("id_penderita")
                    val namaPasien = item.getString("nama_pasien")
                    val kebutuhanDonor = item.getString("kebutuhan_donor")

                    // Perhitungan kuota
                    val pendonor1 = item.optString("pendonor_1", "")
                    val pendonor2 = item.optString("pendonor_2", "")
                    val pendonor3 = item.optString("pendonor_3", "")
                    val pendonor4 = item.optString("pendonor_4", "")

                    var kuotaTerisi = 0
                    if (pendonor1.isNotEmpty()) kuotaTerisi++
                    if (pendonor2.isNotEmpty()) kuotaTerisi++
                    if (pendonor3.isNotEmpty()) kuotaTerisi++
                    if (pendonor4.isNotEmpty()) kuotaTerisi++

                    val kuota = "$kuotaTerisi/4 kuota"

                    listData.add(
                        DataPenderita(
                            idPenderita,
                            namaPasien,
                            kebutuhanDonor,
                            kuota
                        )
                    )
                }
                recyclerView.adapter = DataPenderitaAdapter(listData)
            },
            { error ->
                Toast.makeText(this, "Error: ${error.message}", Toast.LENGTH_LONG).show()
            }
        )

        Volley.newRequestQueue(this).add(request)
    }
}